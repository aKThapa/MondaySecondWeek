/*This is my script file for my game Guess The Number*/



//declare and initialise some global variables which will be used and 
//manipulated throughout the whole script
var randomNumber    = 0;//holds random number
var generateCounter = 0;//counts the amount of time generate button
//has been pressed
var checkCounter    = 0;//counts how many times check button has
//been pressed, this will also be equal to the amount of attempts made


/*console.log("Hello");*/


//add event listener to the generate random number button
document.getElementById('start').addEventListener('click' , generateRandomNumber, false);



/*This function will fire when the generate button is clicked*/
function generateRandomNumber(){
    
    //generate button has been pressed
    generateCounter++;
    
    
    
    
    //Generate a Random number between 1 and 100
    //Only if the generate button has been pressed atleast once that this 
    //function will do actually something
    if(generateCounter === 1)
    {
        
    //this will actually generate the random number
    randomNumber = Math.floor((Math.random() * 100) + 1);
    console.log("Random no is : " + randomNumber);
    
    
    //grab the mainInfo div, which is underneath the
    //generate button
    var display = document.getElementById('mainInfo');
    //create a h4 element 
    var info = document.createElement('h4');
    //Add text to show information about the game
    var text = document.createTextNode('A RANDOM number has been created between 1 and 100 ');
    info.appendChild(text);
    display.appendChild(info);
    
    
    //Add some more texts 
    var info2 = document.createElement('p');
    var text2 = document.createTextNode('Now try to guess to guess it');
    info2.appendChild(text2);
    display.appendChild(info2);
    }
}


//Parameterised function, arguments passed onto it will determine
//the game state
function gameInfo(outCome)
{
    //outCome is based on the difference between 
    //the random number generated and the actual
    //user input(userInput - randomNumber)
    

    //grab the gameInfo div 
    var display = document.getElementById('gameInfo');
    var info = document.createElement('p');
    
    //OutCome 1, means when the user has entered a really bigger value, difference >= 50
    if(outCome === 1)
    {
        //Whats already inside the gameInfo div, lets make it empty
        display.innerHTML = ('');
        //add some text
        var text = document.createTextNode('Way too big');
        info.appendChild(text);
        display.appendChild(info);
    }
    
    
    //outcome 2, mean difference >= 20 but < 50
    if(outCome === 2)
    {
        //Whats already inside the gameInfo div, lets make it empty
        display.innerHTML = ('');
        //add some text
        var text = document.createTextNode('Quite big');
        info.appendChild(text);
        display.appendChild(info);
    }
    
    //outcome 3, means difference >= 10 but < 20
    if(outCome === 3)
    {
        //Whats already inside the gameInfo div, lets make it empty
        display.innerHTML = ('');
        //add some text
        var text = document.createTextNode('Big, but getting there');
        info.appendChild(text);
        display.appendChild(info);
    }
    
    
    //outcome 4, means difference <10 but >=5
    if(outCome === 4)
    {
        //Whats already inside the gameInfo div, lets make it empty
        display.innerHTML = ('');
        //add some text
        var text = document.createTextNode('Getting Really close, but still big');
        info.appendChild(text);
        display.appendChild(info);
    }
    
    //outcome 5, means difference < 5 but >0
    if(outCome === 5)
    {
        //Whats already inside the gameInfo div, lets make it empty
        display.innerHTML = ('');
        //add some text
        var text = document.createTextNode('You are just few steps away,try something smaller');
        info.appendChild(text);
        display.appendChild(info);
    }
    
    //outcome 6, means when the input has been matched
    if(outCome === 6)
    {
        //Whats already inside the gameInfo div, lets make it empty
        display.innerHTML = ('');
        //add some text
        var text = document.createTextNode('Well Done! You have made it');
        info.appendChild(text);
        display.appendChild(info);
    }
    
    if(outCome === 7)
    {
        //Whats already inside the gameInfo div, lets make it empty
        display.innerHTML = ('');
        //add some text
        var text = document.createTextNode('Its more than that');
        info.appendChild(text);
        display.appendChild(info);
    }
}



//Add event listener to the check button
//clicking this button will fire up the Check function
document.getElementById('check').addEventListener('click' , Check, false);


function Check(){
   
//grab the input given by the user
var userInput = document.getElementById('userInput').value;

var diff =  userInput - randomNumber;
console.log('Diff : ' + diff);
    
 if(userInput && generateCounter > 0)
 {
     checkCounter++;
     console.log('Counter = ' + checkCounter);
     console.log('Random no is : ' + randomNumber);
     if(diff >= 50)
     {
         gameInfo(1);
     }
     
     if(diff  < 50  && diff >= 20 )
     {
         gameInfo(2);
     }
     
     if(diff < 20 && diff >= 10)
     {
         gameInfo(3);
     }
     
     if(diff < 10 && diff >= 5 )
     {
         gameInfo(4);
     }
     
     if(diff < 5 && diff > 0)
     {
         gameInfo(5);
     }
     
     
     if(diff === 0)
     {
         gameInfo(6);
         reset();
     }
     
     if(diff < 0)
     {
         gameInfo(7);
        
         
     }
       
}
    else{
        console.log('There is nothing here');
    }
}

function totalGuesses()
{
    console.log('I am at totalGuesses');
    var display = document.getElementById('gameStatsGuess');
    var info = document.createElement('p');
    var text = document.createTextNode('Total Attempts : ' + checkCounter);
    info.appendChild(text);
    display.appendChild(info);
    
    window.setTimeout(correctNumber, 1000);
}

function correctNumber()
{
    console.log('i am at correctNumber');
    var display = document.getElementById('gameStatsCorrectAnswer');
    var info = document.createElement('p');
    var text = document.createTextNode('Correct Number : ' + randomNumber);
    info.appendChild(text);
    display.appendChild(info);
}

function reset()
{
    window.setTimeout(totalGuesses, 1000);
    
    
}

