# JavaScript
This Repository is for all the resources and course material for the JavaScript Training Week
